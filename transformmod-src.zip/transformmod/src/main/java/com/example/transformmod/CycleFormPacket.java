package com.example.transformmod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CycleFormPacket {
    public CycleFormPacket() {}

    public static void encode(CycleFormPacket msg, FriendlyByteBuf buf) {}

    public static CycleFormPacket decode(FriendlyByteBuf buf) {
        return new CycleFormPacket();
    }

    public static void handle(CycleFormPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            Form next = FormEvents.getForm(player).next();
            FormEvents.setForm(player, next);
            player.displayClientMessage(new TextComponent("Forma: " + next.displayName), true);
        });
        ctx.get().setPacketHandled(true);
    }
}
