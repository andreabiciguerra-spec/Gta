package com.example.transformmod;

public enum Form {
    ROBOT("Robot"),
    CAR("Auto"),
    PLANE("Avión"),
    PIRATE("Pirata");

    public final String displayName;

    Form(String displayName) {
        this.displayName = displayName;
    }

    public Form next() {
        Form[] all = values();
        return all[(ordinal() + 1) % all.length];
    }

    public static Form byId(int id) {
        Form[] all = values();
        return id >= 0 && id < all.length ? all[id] : ROBOT;
    }
}
