package com.example.transformmod;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;

public class ClientEvents {
    public static final KeyMapping TRANSFORM_KEY = new KeyMapping(
            "key.transformmod.transform",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_R,
            "key.categories.transformmod");

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (Minecraft.getInstance().player == null) return;
        if (TRANSFORM_KEY.consumeClick()) {
            TransformMod.CHANNEL.sendToServer(new CycleFormPacket());
        }
    }
}
