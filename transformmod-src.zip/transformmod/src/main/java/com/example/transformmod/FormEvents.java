package com.example.transformmod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class FormEvents {
    private static final String TAG = "tf_form";

    public static Form getForm(Player player) {
        return Form.byId(player.getPersistentData().getInt(TAG));
    }

    public static void setForm(ServerPlayer player, Form form) {
        player.getPersistentData().putInt(TAG, form.ordinal());
        clearEffects(player);
        boolean canFlyNormally = player.isCreative() || player.isSpectator();
        if (form == Form.PLANE) {
            player.getAbilities().mayfly = true;
        } else if (!canFlyNormally) {
            player.getAbilities().mayfly = false;
            player.getAbilities().flying = false;
        }
        player.onUpdateAbilities();
        applyEffects(player, form);
    }

    private static void clearEffects(ServerPlayer player) {
        player.removeEffect(MobEffects.MOVEMENT_SPEED);
        player.removeEffect(MobEffects.JUMP);
        player.removeEffect(MobEffects.DAMAGE_BOOST);
        player.removeEffect(MobEffects.DAMAGE_RESISTANCE);
        player.removeEffect(MobEffects.SLOW_FALLING);
    }

    private static void applyEffects(ServerPlayer player, Form form) {
        int dur = 400;
        switch (form) {
            case ROBOT -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, 0, false, false));
            }
            case CAR -> {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, dur, 3, false, false));
                player.addEffect(new MobEffectInstance(MobEffects.JUMP, dur, 1, false, false));
            }
            case PLANE -> {
                player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, dur, 0, false, false));
            }
            case PIRATE -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, dur, 1, false, false));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, 1, false, false));
            }
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 100 != 0) return;
        applyEffects(player, getForm(player));
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone event) {
        event.getPlayer().getPersistentData().putInt(TAG, 0);
    }
}
