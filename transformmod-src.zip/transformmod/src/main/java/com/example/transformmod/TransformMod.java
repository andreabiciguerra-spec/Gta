package com.example.transformmod;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

@Mod(TransformMod.MODID)
public class TransformMod {
    public static final String MODID = "transformmod";
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new net.minecraft.resources.ResourceLocation(MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public TransformMod() {
        CHANNEL.registerMessage(0, CycleFormPacket.class,
                CycleFormPacket::encode, CycleFormPacket::decode, CycleFormPacket::handle);

        MinecraftForge.EVENT_BUS.register(new FormEvents());

        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            FMLJavaModLoadingContext.get().getModEventBus().addListener(TransformMod::clientSetup);
            MinecraftForge.EVENT_BUS.register(new ClientEvents());
        });
    }

    private static void clientSetup(FMLClientSetupEvent event) {
        ClientRegistry.registerKeyBinding(ClientEvents.TRANSFORM_KEY);
    }
}
